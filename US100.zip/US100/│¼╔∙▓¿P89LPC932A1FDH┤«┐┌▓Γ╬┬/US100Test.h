

#ifndef US100Test_H
#define US100Test_H


#include <REG932.H>


void InitIOPort();
//InitIOPort//I2C_Mode//UART_TEMP




#endif


